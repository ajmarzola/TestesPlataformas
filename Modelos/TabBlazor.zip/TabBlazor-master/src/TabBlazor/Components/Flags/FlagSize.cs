﻿namespace TabBlazor
{
    public enum FlagSize
    {
        XSmall,
        Small,
        Medium,
        Large,
        XLarge,
        XXLarge
    }
}


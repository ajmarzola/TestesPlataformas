﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TabBlazor
{
    public enum CarouselIndicator
    {
        None = 0,
        Default = 1,
        Dots = 2,
        Thumbnail = 3
    }

    public enum CarouselIndicatorDirection
    {
        Horizontal = 0,
        Vertical = 1,
      
    }

}

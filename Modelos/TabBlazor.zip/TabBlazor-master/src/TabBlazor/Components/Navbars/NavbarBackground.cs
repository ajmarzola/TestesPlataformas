﻿namespace TabBlazor
{
    public enum NavbarBackground
    {
        Light = 0,
        Dark = 1,
        Transparent = 2

    }
}

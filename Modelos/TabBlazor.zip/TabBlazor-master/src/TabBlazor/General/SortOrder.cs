﻿namespace TabBlazor;

public enum SortOrder
{
    Ascending,
    Descending
}
    
public enum Align
{
    Start,
    End
}
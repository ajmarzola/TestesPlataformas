namespace Tabler.Docs.Data
{
    public class Country
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public Medals Medals { get; set; }
    }
}
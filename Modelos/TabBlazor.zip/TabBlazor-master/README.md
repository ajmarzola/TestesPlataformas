# TabBlazor
A blazor admin template built on [Tabler](https://preview.tabler.io/)

Minimal javascript!

### [Demo](https://TabBlazor.github.io/TabBlazor)

### Getting Started Templates
[TabBlazor.Templates](https://github.com/TabBlazor/TabBlazor.Templates)

### Build 
[![Build](https://github.com/TabBlazor/TabBlazor/actions/workflows/ci.yml/badge.svg)](https://github.com/TabBlazor/TabBlazor/actions/workflows/ci.yml?branch=master)
### Nuget
[![Nuget](https://img.shields.io/nuget/v/tabblazor.svg)](https://www.nuget.org/packages/TabBlazor/)

***Work ongoing***


![Alt text](TabBlazorDashbord.png?raw=true "Dashboard")

Based on [Tabler.Blazor](https://github.com/zarxor/Tabler.Blazor) by [zarxor](https://github.com/zarxor)

